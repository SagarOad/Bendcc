import React from 'react'

const RelatedEvents = () => {
  return (
    <div>RelatedEvents</div>
  )
}

export default RelatedEvents