const EventTagData = [
    { value: 1, label: "Girls" },
    { value: 2, label: "Hair" },
    { value: 3, label: "Health" },
    { value: 3, label: "Man" },
    { value: 4, label: "Nature" },
    { value: 5, label: "People" },
    { value: 6, label: "Portrait" },
    { value: 7, label: "Smile" },
    { value: 8, label: "Work" },
  ];
  
  export default EventTagData;